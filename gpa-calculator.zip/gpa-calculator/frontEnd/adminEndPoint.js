const options = {
    BTC: [
        {value: 'bsub1', text: 'bsub1'},
        {value: 'bsub2', text: 'bsub2'},
        {value: 'bsub3', text: 'bsub3'},
        {value: 'bsub4', text: 'bsub4'},
        {value: 'bsub5', text: 'bsub5'},
        {value: 'bsub6', text: 'bsub6'},
        {value: 'bsub7', text: 'bsub7'},
        {value: 'bsub8', text: 'bsub8'},
    ],
    ETC: [
        {value: 'esub1', text: 'Esub1'},
        {value: 'esub2', text: 'Esub2'},
        {value: 'esub3', text: 'Esub3'},
        {value: 'esub4', text: 'Esub4'},
        {value: 'esub5', text: 'Esub5'},
        {value: 'esub6', text: 'Esub6'},
        {value: 'esub7', text: 'Esub7'},
        {value: 'esub8', text: 'Esub8'},
    ],
    ITC: [
        {value: 'isub1', text: 'Isub1'},
        {value: 'isub2', text: 'Isub2'},
        {value: 'isub3', text: 'Isub3'},
        {value: 'isub4', text: 'Isub4'},
        {value: 'isub5', text: 'Isub5'},
        {value: 'isub6', text: 'Isub6'},
        {value: 'isub7', text: 'Isub7'},
        {value: 'isub8', text: 'Isub8'},
    ]
};

function updateCombo2() {
    const combo1 = document.getElementById('combo1');
    const combo2 = document.getElementById('combo2');
    const selectedValue = combo1.value;

    // Clear the second combo box
    combo2.innerHTML = '<option value="">--Select an option--</option>';

    if (selectedValue && options[selectedValue]) {
        // Populate the second combo box with the corresponding options
        options[selectedValue].forEach(option => {
            const newOption = document.createElement('option');
            newOption.value = option.value;
            newOption.text = option.text;
            combo2.add(newOption);
        });
    }
}
