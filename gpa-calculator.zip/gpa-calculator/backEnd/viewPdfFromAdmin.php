<?php

require 'vendor/autoload.php';

use Smalot\PdfParser\Parser;

$servername = "localhost";
$username = "bhanuka";
$password = "mysql";
$dbname = "gpacalc";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// $id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
$id = 6;

$stmt = $conn->prepare("SELECT filename, filetype, filedata FROM itcresults WHERE id = ?");
$stmt->bind_param("i", $id);
$stmt->execute();
$stmt->bind_result($filename, $filetype, $filedata);
$stmt->fetch();

if ($filename) {
    header("Content-Type: " . $filetype);
    header("Content-Disposition: inline; filename=\"" . $filename . "\"");
    echo $filedata;
} else {
    echo "File not found.";
}

$stmt->close();
$conn->close();
?>
